<div class="page-header">
    <ul class="breadcrumb">
        <li><a href="index.php">Início</a> <span class="divider"></span></li>
        <li><a href="#" class="active">Sobre</a> <span class="divider"></span></li>
    </ul>
    <h1>Sobre</h1>
</div>
<div>
    Sistema desenvolvido para a disciplina de APSOO.
</div>
